#!/bin/bash
echo "Hello world from $(hostname)! I am a $1. Don't tell anyone that the secret is \"$2\""

